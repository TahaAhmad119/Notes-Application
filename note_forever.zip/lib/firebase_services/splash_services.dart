import 'dart:async';

import 'package:note_forever/ui/auth/login.dart';
import 'package:note_forever/ui/posts/post_screem.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SplashServices {
  void isLogin(BuildContext context) {
    final auth=FirebaseAuth.instance;
    final user=auth.currentUser;
    if(user != null){
      Timer(
          const Duration(seconds: 4),
              () => Navigator.push(
              context, MaterialPageRoute(builder: (context) => Home())));
    }else{
      Timer(
          const Duration(seconds: 3),
              () => Navigator.push(
              context, MaterialPageRoute(builder: (context) => Login())));
    }
  }
}
