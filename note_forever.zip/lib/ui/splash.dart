import 'package:flutter/cupertino.dart';
import 'package:note_forever/firebase_services/splash_services.dart';
import 'package:flutter/material.dart';

class splash extends StatefulWidget {
  const splash({super.key});

  @override
  State<splash> createState() => _splashState();
}

class _splashState extends State<splash> {
  SplashServices splashscreen=SplashServices();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    splashscreen.isLogin(context);
  }
  @override
  Widget build(BuildContext context) {
   var size = MediaQuery.of(context).size,height,width;
   height=size.height;
   width=size.width;
    return  Scaffold(
      body: Center(
        child: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                  width: width/2,
                  child: Image.asset('assets/logo.png')),
              Text('Notes Forever',style: TextStyle(fontSize: 35,fontStyle: FontStyle.italic),),
              SizedBox(
                height: height/5,
              ),
              CircularProgressIndicator(
                color: Colors.black,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
