import 'package:note_forever/ui/posts/post_screem.dart';
import 'package:note_forever/utils/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../widgets/roundbutton.dart';


class verify_code extends StatefulWidget {
  final verificationId;
  const verify_code({super.key,required this.verificationId});

  @override
  State<verify_code> createState() => _verify_codeState();
}

class _verify_codeState extends State<verify_code> {
  final verificationcode = TextEditingController();
  final auth = FirebaseAuth.instance;
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size,height,width;
    height=size.height;
    width=size.width;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Center(
            child: Text(
              'Verify',
              style: TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold),
            )),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: height/4,
            ),
            Icon(Icons.password,color: Colors.black,size: width/8,),
            SizedBox(
              height: 50,
            ),
            SizedBox(
              height: 30,
            ),
            TextFormField(
              controller: verificationcode,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(hintText: 'Enter 6 digit code'),
            ),
            SizedBox(
              height: 30,
            ),
            roundbutton(text: "Verify", loading: loading ,onTap: () async{
              setState(() {
                loading=true;
              });
              final credential=PhoneAuthProvider.credential(verificationId: widget.verificationId, smsCode: verificationcode.text.toString());
              try{

                await auth.signInWithCredential(credential);
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Home()));
              }catch(e){
                setState(() {
                  loading=false;
                });
                 Utils().toastMessage(e.toString());
              }
            })
          ],
        ),
      ),
    );
  }
}
