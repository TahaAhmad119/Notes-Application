import 'package:note_forever/ui/auth/verify_code.dart';
import 'package:note_forever/ui/widgets/roundbutton.dart';
import 'package:note_forever/utils/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class login_with_phone extends StatefulWidget {
  const login_with_phone({super.key});

  @override
  State<login_with_phone> createState() => _login_with_phoneState();
}

class _login_with_phoneState extends State<login_with_phone> {
  final phonecontroller = TextEditingController();
  final auth = FirebaseAuth.instance;
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size,height,width;
    height=size.height;
    width=size.width;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Center(
            child: Text(
              'Login',
              style: TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold),
            )),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: height/4,
            ),
            Icon(Icons.phone,color: Colors.black,size: width/8,),
            SizedBox(
              height: 50,
            ),
            TextFormField(
              controller: phonecontroller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(hintText: '+923030252618'),
            ),
            SizedBox(
              height: 50,
            ),
            roundbutton(text: "Login", loading: loading ,onTap: () {
              setState(() {
                loading=true;
              });
              auth.verifyPhoneNumber(
                phoneNumber: phonecontroller.text,
                verificationCompleted: (_) {
                  setState(() {
                    loading=false;
                  });
                },
                verificationFailed: (e) {
                  setState(() {
                    loading=false;
                  });
                  Utils().toastMessage(e.toString());
                },
                codeSent: (String verificationId, int? token) {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) =>
                          verify_code(verificationId: verificationId)));
                  setState(() {
                    loading=false;
                  });
                  },
                codeAutoRetrievalTimeout: (e) {
                  Utils().toastMessage(e.toString());
                  setState(() {
                    loading=false;
                  });
                },
              );
            })
          ],
        ),
      ),
    );
  }
}
