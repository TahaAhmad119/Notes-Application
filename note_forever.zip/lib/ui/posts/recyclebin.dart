import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:note_forever/ui/posts/post_screem.dart';

class RecycleBinScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size,height,width;
    height=size.height;
    width=size.width;
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(color: Colors.white,onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=>Home()));
        },),
        backgroundColor: Colors.black,
        title: Center(child: Padding(
          padding:  EdgeInsets.only(right: width/10),
          child: Text('Recycle Bin',style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        )),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('recyclebin').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (snapshot.data!.docs.isEmpty) {
            return Center(child: Text('Recycle bin is empty'));
          }
          return ListView(
            children: snapshot.data!.docs.map((doc) {
              return ListTile(
                title: Text(doc['title']),
                subtitle: Text(doc['message']),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.restore),
                      onPressed: () => _restoreNote(context, doc.id),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () => _deleteNote(context, doc.id),
                    ),
                  ],
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
  void _restoreNote(BuildContext context, String noteId) async {
    try {
      // Get the note document from the recycle bin collection
      DocumentSnapshot noteDoc =
      await FirebaseFirestore.instance.collection('recyclebin').doc(noteId).get();

      // Check if the document exists and has data
      if (noteDoc.exists && noteDoc.data() != null) {
        // Cast the data to the expected type
        Map<String, dynamic> noteData = noteDoc.data() as Map<String, dynamic>;

        // Move the note back to the main notes collection
        await FirebaseFirestore.instance.collection('notes').doc(noteId).set(noteData);

        // Delete the note from the recycle bin collection
        await FirebaseFirestore.instance.collection('recyclebin').doc(noteId).delete();

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Note restored')));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Note not found')));
      }
    } catch (e) {
      print("Error restoring note: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to restore note')));
    }
  }

  void _deleteNote(BuildContext context, String noteId) async {
    try {
      // Delete the note from the recycle bin collection
      await FirebaseFirestore.instance.collection('recyclebin').doc(noteId).delete();

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Note deleted permanently')));
    } catch (e) {
      print("Error deleting note permanently: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to delete note')));
    }
  }
}
