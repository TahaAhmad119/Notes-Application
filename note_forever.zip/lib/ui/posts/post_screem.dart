import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:note_forever/ui/auth/login.dart';
import 'package:note_forever/ui/posts/notes.dart';
import 'package:note_forever/ui/posts/recyclebin.dart';
import 'package:note_forever/utils/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size,height,width;
    height=size.height;
    width=size.width;
    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>RecycleBinScreen()));
            },
            child: Icon(
          Icons.delete,
          color: Colors.white,
        )),
        automaticallyImplyLeading: false,
        title: Center(
          child: Padding(
            padding:  EdgeInsets.only(right: width/60),
            child: Text(
              'My  Notes',
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        actions: [
          IconButton(
              onPressed: () {
                auth.signOut().then((value) {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Login()));
                }).onError((error, stackTrace) {
                  Utils().toastMessage(error.toString());
                });
              },
              icon: Icon(
                Icons.logout_outlined,
                color: Colors.white,
              )),
          SizedBox(
            width: 10,
          )
        ],
        backgroundColor: Colors.black,
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('notes')
            .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No notes yet'));
          }
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: StaggeredGrid.count(
              crossAxisCount: 2,
              mainAxisSpacing: 10.0,
              crossAxisSpacing: 10.0,
              children: snapshot.data!.docs.map((doc) {
                return InkWell(
                  onTap: () => _showOptionsMenu(context, doc),
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.greenAccent),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Text(doc['title'],
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 30,
                                color: Colors.black,
                              )),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Text(doc['message'],
                              style: TextStyle(
                                fontSize: 20,
                                fontStyle: FontStyle.italic,
                                color: Colors.black,
                              )),
                        )
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.black,
        onPressed: () {
          // Navigate to Note screen
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NoteScreen()),
          );
        },
        child: Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
    );
  }

  void _showOptionsMenu(BuildContext context, DocumentSnapshot note) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.edit),
                title: Text('Edit'),
                onTap: () {
                  Navigator.pop(context);
                  _showUpdateDialog(context, note);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete),
                title: Text('Move to Bin'),
                onTap: () {
                  Navigator.pop(context);
                  _deleteNoteDialog(context, note.id);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showUpdateDialog(BuildContext context, DocumentSnapshot note) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String title = note['title'];
        String message = note['message'];

        TextEditingController titleController =
            TextEditingController(text: title);
        TextEditingController messageController =
            TextEditingController(text: message);

        return AlertDialog(
          title: Text("Update Note"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: titleController,
                decoration: InputDecoration(labelText: 'Title'),
              ),
              TextField(
                controller: messageController,
                decoration: InputDecoration(labelText: 'Message'),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                _updateNote(
                  context,
                  note.id,
                  titleController.text,
                  messageController.text,
                );
                Navigator.of(context).pop();
              },
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void _updateNote(
      BuildContext context, String noteId, String title, String message) async {
    try {
      await FirebaseFirestore.instance.collection('notes').doc(noteId).update({
        'title': title,
        'message': message,
      });
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Note updated successfully')));
    } catch (e) {
      print("Error updating note: $e");
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update note. Please try again')));
    }
  }

  void _deleteNoteDialog(BuildContext context, String noteId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Move to Bin"),
          content: Text("Are you sure you want to delete this note?"),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                _deleteNote(context, noteId);
                Navigator.of(context).pop();
              },
              child: Text('Move to Bin'),
            ),
          ],
        );
      },
    );
  }

  void _deleteNote(BuildContext context, String noteId) async {
    try {
      // Get the note document
      DocumentSnapshot noteDoc = await FirebaseFirestore.instance
          .collection('notes')
          .doc(noteId)
          .get();

      // Check if the document exists and has data
      if (noteDoc.exists && noteDoc.data() != null) {
        // Cast the data to the expected type
        Map<String, dynamic> noteData = noteDoc.data() as Map<String, dynamic>;

        // Move the note to the recycle bin collection
        await FirebaseFirestore.instance
            .collection('recyclebin')
            .doc(noteId)
            .set(noteData);

        // Delete the note from the main notes collection
        await FirebaseFirestore.instance
            .collection('notes')
            .doc(noteId)
            .delete();

        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Note moved to recycle bin')));
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Note not found')));
      }
    } catch (e) {
      print("Error moving note to recycle bin: $e");
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to move note to recycle bin')));
    }
  }

  void _navigateToAddNoteScreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NoteScreen()),
    );
  }
}
