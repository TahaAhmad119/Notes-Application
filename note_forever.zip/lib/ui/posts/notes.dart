import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:note_forever/ui/auth/login.dart';
import 'package:note_forever/ui/posts/post_screem.dart';
import 'package:note_forever/ui/posts/recyclebin.dart';
import 'package:note_forever/main.dart';
class NoteScreen extends StatefulWidget {
  @override
  State<NoteScreen> createState() => _NoteScreenState();
}

class _NoteScreenState extends State<NoteScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size,height,width;
    height=size.height;
    width=size.width;
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(color: Colors.white,),
        backgroundColor: Colors.black,
        title: Center(
          child: Padding(
            padding:  EdgeInsets.only(right: width/10),
            child: Text(
              'Add Notes',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'Title of Notes',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: _messageController,
              decoration: InputDecoration(
                labelText: 'Write Here Your Notes',
                border: OutlineInputBorder(),
              ),
              maxLines: null,
            ),
            SizedBox(
              height: 50,
            ),
            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>RecycleBinScreen()));
              },
              child: Column(
                children: [
                  Icon(Icons.delete,color: Colors.black,size: 50,),
                  SizedBox(height: 5,),
                  Text('Recycle Bin'),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _saveNote(context);
        },
        child: Icon(Icons.note_add),
      ),
    );
  }

  void _saveNote(BuildContext context) async {
    print('object');
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      print('n');
      final String title = _titleController.text.trim();
      final String message = _messageController.text.trim();
      if (title.isNotEmpty && message.isNotEmpty) {
        try {
          await FirebaseFirestore.instance.collection('notes').add({
            'userId': currentUser.uid,
            'title': title,
            'message': message,
            'createdAt': FieldValue.serverTimestamp(),
          });
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved')));
          Navigator.push(context, MaterialPageRoute(builder: (context) => Home()));
        } catch (error) {
          print('Error saving note: $error');
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to save note')));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fill both fields')));
      }
    }
  }
}
